# Raspadinha Online (Next.js)

Projeto pronto para deploy na Vercel.

## Scripts
- `npm run dev` — desenvolvimento
- `npm run build` — build de produção
- `npm start` — servir build

## Como publicar na Vercel (pelo celular)
1. No GitHub, crie um repositório vazio.
2. Toque em **Add file > Upload files** e envie **todos os arquivos e pastas** desta raiz (não a pasta inteira zipada).
3. Na Vercel, clique em **Import Project** > escolha GitHub > selecione o repositório > **Deploy**.

## Observações
- Tailwind configurado via `pages/_app.js` e `styles/globals.css`.
- A imagem `public/capa-raspadinha.png` está como placeholder (1x1). Substitua por uma arte real se desejar.
