import Navbar from "../components/Navbar";

export default function Comprar() {
  return (
    <>
      <Navbar />
      <div className="p-10 max-w-lg mx-auto">
        <h2 className="text-2xl font-bold mb-4">Comprar Raspadinha</h2>
        <form action="/jogar" method="GET" className="flex flex-col space-y-4">
          <input type="text" placeholder="Nome completo" required className="border p-2 rounded" />
          <input type="text" placeholder="CPF" required className="border p-2 rounded" />
          <input type="email" placeholder="E-mail" required className="border p-2 rounded" />
          <button type="submit" className="bg-green-500 text-white p-3 rounded hover:bg-green-600">
            Pagar via PIX (Simulação)
          </button>
        </form>
      </div>
    </>
  );
}