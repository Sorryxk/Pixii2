export default function Navbar() {
  return (
    <nav className="bg-yellow-500 p-4 flex justify-between items-center shadow">
      <h1 className="text-white font-bold text-xl">🎯 Sua Raspadinha</h1>
      <div>
        <a href="/" className="text-white mr-4">Home</a>
        <a href="/comprar" className="text-white">Comprar</a>
      </div>
    </nav>
  )
}