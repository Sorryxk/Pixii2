import ScratchCard from 'react-scratchcard';

export default function ScratchGame({ resultado }) {
  const settings = {
    width: 300,
    height: 300,
    image: '/capa-raspadinha.png',
    finishPercent: 50,
    onComplete: () => alert(`Resultado: ${resultado}`),
  };

  return (
    <div className="flex flex-col items-center mt-8">
      <ScratchCard {...settings}>
        <div className="w-full h-full bg-white flex items-center justify-center text-xl font-bold">
          {resultado}
        </div>
      </ScratchCard>
    </div>
  );
}