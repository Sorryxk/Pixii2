import Navbar from "../components/Navbar";

export default function Home() {
  return (
    <>
      <Navbar />
      <section className="text-center p-10">
        <h1 className="text-4xl font-bold mb-4">Compre e Raspe Online!</h1>
        <p className="mb-6 text-gray-700">
          Participe de forma rápida e segura. Número do processo SUSEP: 12345.6789/2025-00.
        </p>
        <a
          href="/comprar"
          className="bg-yellow-500 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-yellow-600"
        >
          Comprar Raspadinha
        </a>
      </section>
    </>
  );
}