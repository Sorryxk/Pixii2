import Navbar from "../components/Navbar";
import ScratchGame from "../components/ScratchCard";

export default function Jogar() {
  const resultado = Math.random() < 0.5 ? "🎉 Você ganhou R$ 100!" : "😢 Não foi dessa vez";

  return (
    <>
      <Navbar />
      <div className="text-center">
        <h2 className="text-2xl font-bold mt-4">Raspe para revelar seu prêmio</h2>
        <ScratchGame resultado={resultado} />
      </div>
    </>
  );
}